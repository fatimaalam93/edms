
<script src="{{asset('public/web_assets/js/popper.min.js')}}"></script>
<script src="{{asset('public/web_assets/js/bootstrap.min.js')}}"></script>
<script src="{{asset('public/web_assets/js/bootstrap-dropdownhover.min.js')}}"></script>
<script src="{{asset('public/web_assets/js/bootstrap-slider.js')}}"></script>
<script src="{{asset('public/web_assets/js/jquery.flexslider-min.js')}}"></script>
<script src="{{asset('public/web_assets/js/slick.min.js')}}"></script>
<script src="{{asset('public/web_assets/js/owl.carousel.min.js')}}"></script>
<script src="{{asset('public/web_assets/js/retina.min.js')}}"></script>
<script src="{{asset('public/web_assets/js/css3-animate-it.js')}}"></script>
<script src="{{asset('public/web_assets/js/magnific-popup.min.js')}}"></script>
<script src="{{asset('public/web_assets/js/jquery.fancybox.js')}}"></script>
<script src="{{asset('public/web_assets/js/gallery.js')}}"></script>
<script src="{{asset('public/web_assets/js/player-min.js')}}"></script>
<script src="{{asset('public/web_assets/js/script.js')}}"></script>
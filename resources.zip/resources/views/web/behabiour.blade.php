@include('web.header')
<body cz-shortcut-listen="true" class="" style="">
    <div class="wrapper">

    <div class="preloader" style="display: none;"></div>

    <!-- Page-wrapper Start-->
    <div class="page-wrapper">
        <style type="text/css">
            .banner-section{
                 background-image: url("public/web_assets/img/bg4.jpg");
            }
        </style>

    @include('web.menu')
 <!-- Banner Section Start -->
        <section class="banner-section pt-100 pb-70">
            <div class="container">
                <div class="row">
                    <div class="banner style-1">
                        <h2>Behaviour</h2>
                        <div class="banner-link">
                            <ul>
                                <li><i class="fa fa-angle-right"></i><a href="#">Home</a></li>
                                <li><i class="fa fa-angle-right"></i><a href="#">Behaviour Dtails</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Banner Section End -->

        <!-- Details Section Start -->
        <section class="service-details-section pt-70 pb-70">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-12">
                        <div class="service-details">
                            <div class="thumb">
                                <img src="./Health-Sheba __ Health &amp; Medical HTML Template_files/d1.jpg" alt="">
                            </div>
                            <div class="content">
                                <h1>Outcome of Support Plan and Intended Outcomes</h1>
                            
                                <p class="mb-40">To Support Joe in managing his challenging behaviour.
To try to reduce any triggers or environmental factors that may cause behavioral problems.
To reduce the occurance of any behaviours that may occur.To Support Joe in managing his challenging behaviour.
To try to reduce any triggers or environmental factors that may cause behavioral problems.
To reduce the occurance of any behaviours that may occur.To Support Joe in managing his challenging behaviour.
To try to reduce any triggers or environmental factors that may cause behavioral problems.
To reduce the occurance of any behaviours that may occur.To Support Joe in managing his challenging behaviour.
To try to reduce any triggers or environmental factors that may cause behavioral problems.
To reduce the occurance of any behaviours that may occur.</p>


<p class="mb-40">To Support Joe in managing his challenging behaviour.
To try to reduce any triggers or environmental factors that may cause behavioral problems.
To reduce the occurance of any behaviours that may occur.To Support Joe in managing his challenging behaviour.
To try to reduce any triggers or environmental factors that may cause behavioral problems.
To reduce the occurance of any behaviours that may occur.To Support Joe in managing his challenging behaviour.
To try to reduce any triggers or environmental factors that may cause behavioral problems.
To reduce the occurance of any behaviours that may occur.To Support Joe in managing his challenging behaviour.
To try to reduce any triggers or environmental factors that may cause behavioral problems.
To reduce the occurance of any behaviours that may occur.</p>
                                
                                <!-- <div class="row">
                                    <div class="col-md-12">
                                        <div class="list-content row">
                                            <div class="col-md-6 col-sm-6">
                                                <h5 class="list-item">
                                                    <a href="http://heatmaponline.com/html/hseba/depertment-1.html#"><i class="flaticon-right-arrow"></i>We serve better than any other</a>
                                                </h5>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <h5 class="list-item">
                                                    <a href="http://heatmaponline.com/html/hseba/depertment-1.html#"><i class="flaticon-right-arrow"></i>We serve better than any other</a>
                                                </h5>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <h5 class="list-item">
                                                    <a href="http://heatmaponline.com/html/hseba/depertment-1.html#"><i class="flaticon-right-arrow"></i>We serve better than any other</a>
                                                </h5>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <h5 class="list-item">
                                                    <a href="http://heatmaponline.com/html/hseba/depertment-1.html#"><i class="flaticon-right-arrow"></i>We serve better than any other</a>
                                                </h5>
                                            </div>
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                        <!-- <blockquote>
                            <p>"Lorem ipsum dolor sit amet, consectetur adipiscing duis mollis, est non commodo luctus elit posuere erat a ante. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis lorem ipsum dolor sit amet, consectetur adipiscing"</p>
                        </blockquote> -->
                        <!-- <div class="row">
                            <div class="col-md-4">
                                <div class="section-content">
                                    <div class="service-item style-2">
                                        <div class="thumb">
                                            <img alt="" src="./Health-Sheba __ Health &amp; Medical HTML Template_files/1.jpg">
                                            <div class="service-icon">
                                                <i class="flaticon-orthopedics"></i>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <h4 class="mb-10">Health <span>Orthopaedics</span></h4>
                                            <p>Health amet, consectetur ipisicing elit. Dolores</p>
                                            <a href="http://heatmaponline.com/html/hseba/depertment-1.html#" class="link-btn">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="section-content">
                                    <div class="service-item style-2">
                                        <div class="thumb">
                                            <img alt="" src="./Health-Sheba __ Health &amp; Medical HTML Template_files/2.jpg">
                                            <div class="service-icon">
                                                <i class="flaticon-dental-1"></i>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <h4 class="mb-10">Health <span>Spine Care</span></h4>
                                            <p>Health amet, consectetur ipisicing elit. Dolores</p>
                                            <a href="http://heatmaponline.com/html/hseba/depertment-1.html#" class="link-btn">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="section-content">
                                    <div class="service-item style-2">
                                        <div class="thumb">
                                            <img alt="" src="./Health-Sheba __ Health &amp; Medical HTML Template_files/3.jpg">
                                            <div class="service-icon">
                                                <i class="flaticon-child"></i>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <h4 class="mb-10">Health <span>Cancer Care</span></h4>
                                            <p>Health amet, consectetur ipisicing elit. Dolores</p>
                                            <a href="http://heatmaponline.com/html/hseba/depertment-1.html#" class="link-btn">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </section>
        <!-- Details Section End -->
    <div class="site-footer-space"></div>

        <!-- Footer Style One Start -->
        @include('web.footer')
        <!-- Footer Style One End -->

        <section class="sign-in-model">
            <!-- Login -->
            <div class="modal fade theme-login theme-model" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Login</h4>
                            <a class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></a>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="sign-name-1" placeholder="Enter Name">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="sign-password-1" placeholder="Password">
                                </div>
                                <a class="btn btn-theme mt-2" href="http://heatmaponline.com/html/hseba/index-two.html#">Sign In</a>
                                <div class="row mt-5">
                                    <div class="col-sm-6">
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <input type="checkbox" class="form-check-input"> Remember Me</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 text-right">
                                        <a href="http://heatmaponline.com/html/hseba/index-two.html#">Forgot Password</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <div class="mb-2"> Don't Have an Account? <a href="http://heatmaponline.com/html/hseba/index-two.html#" class="theme-color">Register Now</a></div>
                            <ul class="theme-media-blog">
                                <li><a href="http://heatmaponline.com/html/hseba/index-two.html#"><i class="fa fa-twitter "></i></a></li>
                                <li><a href="http://heatmaponline.com/html/hseba/index-two.html#"><i class="fa fa-facebook "></i></a></li>
                                <li><a href="http://heatmaponline.com/html/hseba/index-two.html#"><i class="fa fa-google "></i></a></li>
                                <li><a href="http://heatmaponline.com/html/hseba/index-two.html#"><i class="fa fa-github "></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Login -->

            <!-- Register -->
            <div class="modal fade theme-register theme-model" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Register</h4>
                            <a class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></a>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="sign-username" placeholder="User Name">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="sign-email" placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="sign-password" placeholder="Password">
                                </div>
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input type="checkbox" class="form-check-input"> I Agree to the Terms and Conditions</label>
                                </div>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                <a class="btn btn-theme" href="http://heatmaponline.com/html/hseba/index-two.html#">Sign Up</a>
                            </form>
                        </div>
                        <div class="modal-footer text-center">
                            <div class="mb-3"> Already Have an Account? <a href="http://heatmaponline.com/html/hseba/index-two.html#" class="theme-color">Login</a></div>
                            <ul class="theme-media-blog">
                                <li><a href="http://heatmaponline.com/html/hseba/index-two.html#"><i class="fa fa-twitter "></i></a></li>
                                <li><a href="http://heatmaponline.com/html/hseba/index-two.html#"><i class="fa fa-facebook "></i></a></li>
                                <li><a href="http://heatmaponline.com/html/hseba/index-two.html#"><i class="fa fa-google "></i></a></li>
                                <li><a href="http://heatmaponline.com/html/hseba/index-two.html#"><i class="fa fa-github "></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Register -->
        </section>

    </div>
    <!-- Page-wrapper End -->

    <a href="#" class="scrollup" style="display: none;"><i class="pe-7s-up-arrow" aria-hidden="true"></i></a>

    <!-- Main JavaScript -->
    @include('web.footer_js')
    

  </div><style type="text/css">.txt-rotate > .wrap { border-right: 0.08em solid #666 }</style></body></html>